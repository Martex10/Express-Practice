const express = require("express");
const app = express();
//lets express make sense of the request data sent from post request
const bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({extended: true }));
//lets us leave .ejs off of file names
app.set("view engine", "ejs");

//arry will add data base later
let friends = ["Tony", "ChiCHi", "Bri", "Samantha", "Justin", "JC"];

app.get("/", function(req, res){
    res.render("home");
});

app.post("/addfriend", function(req, res){
    //lets us gather data that was sent from form on site
   let newFriend = req.body.newfriend;
   //add new friend to friends list
   friends.push(newFriend);
    res.redirect("/friends");
});
//take you to friends page
app.get("/friends", function(req, res){
   res.render("friends", {friends: friends}); 
});

app.listen(process.env.PORT, process.env.IP, function(){
    console.log("SERVER HAS STARTED");
});